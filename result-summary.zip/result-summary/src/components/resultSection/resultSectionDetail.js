import React from "react";

function ResultSectionDetail({
    category,
    score,
    icon,
    backgroundColor,
    color,
}) {
    return (
        <div
            className="summary_each margin__bottom__15"
            style={{
                backgroundColor: backgroundColor,
            }}
        >
            <img src={icon} alt="icon" />
            <div
                className="category"
                style={{
                    color: color,
                    fontWeight: "bold",
                }}
            >
                {category}
            </div>
            <div className="score">{score} / 100</div>
        </div>
    );
}

export default ResultSectionDetail;
