import React from "react";
import ResultSectionDetail from "./resultSectionDetail";

const BACKGROUND_COLOR_ARRAY = ["#FFF5f6", "#FEFBF2", "#F2FAFA", "#F3F3FD"];
const COLOR_ARRAY = ["#D26E6A", "#EFC77B", "#50AD95", "#7479E3"];

function ResultSection({ results }) {
    return (
        <section className="resultsection">
            <h2 className="margin__bottom__15">Summary</h2>
            {results.length > 0 &&
                results.map((result, i) => {
                    return (
                        <ResultSectionDetail
                            key={i}
                            {...result}
                            backgroundColor={BACKGROUND_COLOR_ARRAY[i]}
                            color={COLOR_ARRAY[i]}
                        />
                    );
                })}
        </section>
    );
}

export default ResultSection;
