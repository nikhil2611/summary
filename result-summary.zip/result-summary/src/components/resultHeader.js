import React from "react";

function ResultHeader() {
    return (
        <section className="display__center font__white result__header">
            <h3 className="off__white margin__bottom__15">Your Result</h3>
            <div id="circle" className="font__white margin__bottom__15">
                <div>
                    <h1 className="total">76</h1>
                    <h4 className="off__white">of 100</h4>
                </div>
            </div>
            <h3>Great</h3>
            <p
                className="off__white"
                style={{
                    padding: "0 68px",
                }}
            >
                {" "}
                You scored higher than 65% of the people who have taken these
                tests.
            </p>
        </section>
    );
}

export default ResultHeader;
