import { useEffect, useState } from 'react';
import ResultHeader from './components/resultHeader';
import ResultSection from './components/resultSection/resultSection';
import fetchData from './data'
import './App.css';

function App() {
  const [results, setResults] = useState([]);

  useEffect(() => {
    (async()=> {
      const data =  await fetchData();
      setResults(data);
    })()
  }, [])

  return (
    <div className="App">
      <ResultHeader />
      <ResultSection results={results}/>
    </div>
  );
}

export default App;
